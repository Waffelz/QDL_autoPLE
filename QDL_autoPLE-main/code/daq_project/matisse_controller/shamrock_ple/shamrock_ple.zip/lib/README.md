# Andor SDK and Shamrock Libraries

Some proprietary libraries cannot be distributed with this application.

Let `{SDK}` be the directory to where you've installed the Andor SDK v2.103.30031. Lab members can download this SDK from the
Dropbox.

You should copy the following files to this directory:
- `{SDK}\atmcd64d.dll`
- `{SDK}\Shamrock64\atshamrock.dll`
- `{SDK}\Shamrock64\ShamrockCIF.dll`
